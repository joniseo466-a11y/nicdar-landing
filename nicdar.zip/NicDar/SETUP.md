# NichoRadar - YouTube Analytics Extension

## Instalación

### 1. Generar iconos PNG
1. Abre `assets/icons/generate-icons.html` en el navegador
2. Descarga los 3 iconos PNG y guárdalos en `assets/icons/`

### 2. Descargar xlsx.js (SheetJS)
Descarga la librería para exportar Excel:
- Ve a https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.mini.min.js
- Guarda el archivo como `lib/xlsx.min.js`

O ejecuta este comando PowerShell desde la carpeta del proyecto:
```powershell
Invoke-WebRequest -Uri "https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.mini.min.js" -OutFile "lib\xlsx.min.js"
```

### 3. Configurar YouTube Data API v3
1. Ve a [Google Cloud Console](https://console.cloud.google.com/)
2. Crea un proyecto nuevo o selecciona uno existente
3. Habilita "YouTube Data API v3"
4. Ve a Credentials > Create Credentials > API Key
5. Copia la API Key

### 4. Instalar la extensión en Chrome
1. Abre `chrome://extensions/`
2. Activa "Modo desarrollador" (esquina superior derecha)
3. Clic en "Cargar extensión sin empaquetar"
4. Selecciona la carpeta `youtube-analytics-extension`

### 5. Configurar API Key
1. Haz clic en el icono de NichoRadar en la barra de extensiones
2. Ve a la pestaña "Settings"
3. Pega tu YouTube API Key y haz clic en "Guardar"

## Uso

### En YouTube:
- **VPH (Views Per Hour)**: Aparece automáticamente debajo de cada video
  - Verde: >100 VPH | Amarillo: 50-100 VPH | Rojo: <50 VPH
- **Suscriptores**: Badge con conteo debajo de cada video
- **Monetización**: Badge en páginas de canal
- **Similar Channels**: Botón flotante en páginas de canal
- **Save To Swipefile**: Botón en páginas de canal para guardar

### En el Popup:
- **Swipefile**: Lista de canales guardados con búsqueda y filtros
- **Export**: Exportar a Excel (.xlsx) o CSV
- **Settings**: Configurar API Key y ver cuota

## Cuota de API
YouTube Data API tiene un límite de 10,000 unidades/día:
- videos.list: 1 unidad
- channels.list: 1 unidad
- search.list: 100 unidades (usado en Similar Channels)

La extensión usa caché de 5 minutos y batch requests para optimizar.
